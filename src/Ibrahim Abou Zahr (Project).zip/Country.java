
public class Country {
	protected int CountryNumber;
	
	
}
